# 中国留学生商科岗位求职：模板与案例包

作者：AI 酋长 Andy｜微信 AIPMAndy｜公众号 AI酋长Andy
个人官网：https://metaver.vip/｜公司官网：https://www.a6no1.cn/
版本：1.0 · 2026-11-13

先读 templates/README.md，再选 cases/ 下的一条路线。每套包含题面、数据、参考解、评分与追问；printable-data.md 是可打印输入。
downloads/business-job-workbook.xlsx 包含七张可编辑表。templates/csv/ 可用表格软件导入；CSV 不保留公式、样式或下拉。
所有案例与申请样例都是完整教学模拟，不是真实客户经历，不应写成已完成的商业工作。
content/ 是独立可读的完整正文。SOURCES.md 和 research/ 给出官方来源、日期与限制。
正式网站采用 GitHub Pages；发布状态见完整项目中的 VERIFY.md。
目标地址：https://aipmandy.github.io/chinese-international-student-business-jobs/ （未完成线上验收前仅为目标地址）
免费内容完整开放；可选咨询承接职业方向判断、申请材料诊断与面试陪跑，不承诺录用或薪资。
授权：原创文字与合成数据 CC BY 4.0，代码 MIT。见随包授权文件。
